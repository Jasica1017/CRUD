const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const movieRoutes = require('./routes/movies');
const reviewRoutes = require('./routes/reviews');

const app = express();
const PORT = process.env.PORT || 3000;

// MongoDB connection
const password = '24sfVFsqwl4mBvn1';
const uri = `mongodb+srv://jasica0680be21:${password}@cluster0.ahwctjc.mongodb.net/bookstore?retryWrites=true&w=majority`

mongoose.connect(uri, {
    useNewUrlParser : true,
    useUnifiedTopology: true
})
.then(() => console.log(`DB connected`))
.catch(() => console.log(`Error`))
// Middleware
app.use(bodyParser.json());

// Routes
app.use('/api/movies', movieRoutes);
app.use('/api/movies/:movieId/reviews', reviewRoutes);

// Start server
app.listen(PORT, () => {
    console.log("http://localhost:3000");
});
