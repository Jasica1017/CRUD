const express = require('express');
const router = express.Router();
const Movie = require('../models/movie');

// Add a new review to a movie
router.post('/', async (req, res) => {
  const { movieId } = req.params;
  try {
    const movie = await Movie.findById(movieId);
    if (!movie) {
      return res.status(404).json({ error: 'Movie not found' });
    }
    movie.reviews.push(req.body);
    await movie.save();
    res.status(201).json(movie.reviews[movie.reviews.length - 1]);
  } catch (error) {
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

// Retrieve all reviews for a specific movie with pagination
router.get('/', async (req, res) => {
  const { movieId } = req.params;
  const { page = 1, pageSize = 10 } = req.query;
  try {
    const movie = await Movie.findById(movieId);
    if (!movie) {
      return res.status(404).json({ error: 'Movie not found' });
    }
    const reviews = movie.reviews.slice((page - 1) * pageSize, page * pageSize);
    res.json(reviews);
  } catch (error) {
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

// Update a review by ID within a movie
router.put('/:reviewId', async (req, res) => {
  const { movieId, reviewId } = req.params;
  try {
    const movie = await Movie.findById(movieId);
    if (!movie) {
      return res.status(404).json({ error: 'Movie not found' });
    }
    const review = movie.reviews.id(reviewId);
    if (!review) {
      return res.status(404).json({ error: 'Review not found' });
    }
    Object.assign(review, req.body);
    await movie.save();
    res.json(review);
  } catch (error) {
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

// Delete a review by ID within a movie
router.delete('/:reviewId', async (req, res) => {
  const { movieId, reviewId } = req.params;
  try {
    const movie = await Movie.findById(movieId);
    if (!movie) {
      return res.status(404).json({ error: 'Movie not found' });
    }
    const review = movie.reviews.id(reviewId);
    if (!review) {
      return res.status(404).json({ error: 'Review not found' });
    }
    review.remove();
    await movie.save();
    res.json({ message: 'Review deleted successfully' });
  } catch (error) {
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

module.exports = router;
